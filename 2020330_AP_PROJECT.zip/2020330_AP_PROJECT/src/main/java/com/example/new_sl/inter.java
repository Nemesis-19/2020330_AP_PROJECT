package com.example.new_sl;

public interface inter {
    public String getName();
}
